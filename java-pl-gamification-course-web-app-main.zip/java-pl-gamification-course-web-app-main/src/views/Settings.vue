<template>
  <div>

  </div>
</template>

<script>

export default {
name: "Settings",
  components: {
  },
  data() {
    return {
    }
  },
  created(){
  },
  methods: {
  }
}
</script>

<style scoped>
  body {
    background-color: indianred;
  }
</style>

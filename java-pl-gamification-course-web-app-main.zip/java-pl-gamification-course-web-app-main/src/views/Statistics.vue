<template>
  <div class="map">

  </div>
</template>

<script>

export default {
name: "Statistics",
  components: {
  },
  data() {
    return {
    }
  },
  created(){
  },
  methods: {
  }
}
</script>

<style scoped>
  .map{
    background: indigo;
    height: 100vh;
    margin: 0;
    padding: 0;
  }
</style>

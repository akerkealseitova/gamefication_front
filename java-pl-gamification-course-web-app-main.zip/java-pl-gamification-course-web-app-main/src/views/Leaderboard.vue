<template>
  <div class="">

  </div>
</template>

<script>

export default {
name: "Leaderboard",
  components: {
  },
  data() {
    return {
    }
  },
  created(){
  },
  methods: {
  }
}
</script>

<style scoped>
  body{
    background: darkgrey;
  }
</style>

<template>
  <course-content-nav></course-content-nav>
</template>

<script>
import CourseContentNav from '../components/CourseContentNav.vue'
export default {
  name: "CourseContentContest",
  data() {
    return {
    };
  },
  mounted() {
  },
  methods: {
  },
  components: {
    CourseContentNav
  }
};
</script>

<style lang="scss" scoped>
</style>

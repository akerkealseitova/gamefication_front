package sample.Obstacles;

import javafx.scene.image.Image;

public class Tree extends Obstacle{
    private Image image = new Image("img/Tree.png");

    public Tree(){
        super();
        Constructor(image, false, true, true, true);
    }
}

package sample.Obstacles;

import javafx.scene.image.Image;

public class NormalCell extends Obstacle{
    private Image image = new Image("img/Black.png");
    public NormalCell(){
        super();
        Constructor(image, false, true, true, false);
    }

}

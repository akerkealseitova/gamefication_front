package sample.Obstacles;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Obstacle {
    private boolean canBroken, canSkipBullet, canSkipTank, canHide;
    public int obstacleHealth=1;
    private Image image;

    public Obstacle(){
    }

    public void Constructor(Image image, boolean canBroken, boolean canSkipBullet, boolean canSkipTank, boolean canHide){
        this.image = image;
        this.canBroken = canBroken;
        this.canSkipBullet = canSkipBullet;
        this.canSkipTank = canSkipTank;
        this.canHide = canHide;
    }

    public void destroy(){
        if(canBroken && obstacleHealth > 0){
            obstacleHealth--;
        }
    }

    public void drawObstacle(GraphicsContext gc, int x, int y, int size){
        gc.drawImage(image, x*size, y*size);
    }

    public int getObstacleHealth(){
        return this.obstacleHealth;
    }

    public boolean CheckerSkipB() {
        return canSkipBullet;
    }

    public boolean CheckerSkipT() {
        return canSkipTank;
    }

    public boolean CheckerHide() {
        return canHide;
    }
}


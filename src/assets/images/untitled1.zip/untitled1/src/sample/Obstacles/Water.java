package sample.Obstacles;

import javafx.scene.image.Image;

public class Water extends Obstacle {
    private Image image = new Image("img/Water.png");
    public Water(){
        super();
        Constructor(image, false, true, false, false);
    }
}

package sample.Obstacles;

import javafx.scene.image.Image;

public class SteelWall extends Obstacle {
    private Image image = new Image("img/SWall.png");
    public SteelWall(){
        super();
        Constructor(image, false, false, false, false);
    }
}

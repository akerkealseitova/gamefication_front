package sample.Obstacles;

import javafx.scene.image.Image;

public class Brick extends Obstacle{
    private Image image = new Image("img/Kirpiw.png");
    public Brick(){
        super();
        Constructor(image, true, false, false, false);
            super.obstacleHealth = 4;
    }
}

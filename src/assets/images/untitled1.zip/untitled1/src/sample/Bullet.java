package sample;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class Bullet {
    private char TankDirection;
    private Position position;
    private Map map;
    private boolean isAlive = true;
    private boolean isHidden = false;
    private int cSize;

    public Bullet(Position position, char direction, int cellSize,Map map){
        this.position = new Position(position.getX(), position.getY());
        this.TankDirection = direction;
        this.cSize = cellSize;
        this.map=map;
    }

    public void update(GraphicsContext gc){
        updatePosition();
        drawBullet(gc);
    }

    private void updatePosition(){
        if(TankDirection =='l')
            moveTo(position.getX()-1, position.getY());
        else if(TankDirection =='u')
            moveTo(position.getX(), position.getY()-1);
        else if(TankDirection =='d')
            moveTo(position.getX(), position.getY()+1);
        else if(TankDirection =='r')
            moveTo(position.getX()+1, position.getY());

    }

    private void moveTo(int x, int y){
        if(MoveChecker(x, y)){
            position.setX(x);
            position.setY(y);
        }else{
            map.DeleteBlock(x, y);
            isAlive = false;
        }
    }

    private boolean MoveChecker(int x, int y){
        if(!map.CheckerMap(x, y)){
            return false;
        }
        if(map.getValueAt(x, y).CheckerSkipB()){
            isHidden = map.getValueAt(x, y).CheckerHide();
            return true;
        }
        return false;
    }

    private void drawBullet(GraphicsContext gc){
        if(isHidden){
            return;
        }
        gc.setFill(Color.WHITE);
        double rad = cSize / 4;
        gc.fillOval(position.getX() * cSize + cSize / 2 - cSize / 8 , position.getY() * cSize + cSize / 2 - cSize / 8, rad, rad);
    }
    public boolean isAlive(){ return isAlive; }
}

package sample;

import javafx.scene.canvas.GraphicsContext;
import sample.Obstacles.*;

import java.util.Scanner;

public class Map {
    private Scanner scan;
    private Obstacle[][] map;
    private int mapSize;
    private int cellSize;
    private Position PxANDPy;

    Map(Scanner scan) throws Exception{
        this.scan = scan;
        mapSize = scan.nextInt();
        if(mapSize == 0){
            throw new InvalidMapException("Map size can not be zero");
        }

        map = new Obstacle[mapSize][mapSize];

        for(int i = 0; i < mapSize; i++){
            for(int j = 0; j < mapSize; j++){
                char a = scan.next().charAt(0);
                ObstacleMap(a, i, j);
                if(a == 'P'){
                    PxANDPy = new Position(j, i);
                }
            }
        }
    }

    private void ObstacleMap(char a, int i, int j) throws Exception{
        if(!isValid(a)){
            throw new InvalidMapException("Not enough map elements");
        }
        if(a == 'S'){
            map[i][j] = new SteelWall();
        }else if(a == 'W'){
            map[i][j] = new Water();
        }else if(a == 'T'){
            map[i][j] = new Tree();
        }else if(a == 'B'){
            map[i][j] = new Brick();
        }else{
            map[i][j] = new NormalCell();
        }
    }

    private boolean isValid(Character c) {
        boolean a=(c == '0' || c == 'T' || c == 'B' || c == 'S' || c == 'W' || c == 'P');
        return a;
    }

    public void drawMap(GraphicsContext gc){
        for(int i = 0; i < mapSize; i++){
            for(int j = 0; j < mapSize; j++){
                map[i][j].drawObstacle(gc, j, i, cellSize);
            }
        }
    }

    public void setCellSize(int cellSize){
        this.cellSize = cellSize;
    }

    public void DeleteBlock(int x, int y){
        if(CheckerMap(x, y)) {
            map[y][x].destroy();
            if(getValueAt(x, y).getObstacleHealth() == 0){ // if Brick block destroyed, then replace it to Normal Cell
                map[y][x] = new NormalCell();
            }
        }
    }

    public boolean CheckerMap(int x, int y){
        boolean isValidX=false;
        if(x >= 0 && x < mapSize){
            isValidX=true;
        }
        boolean isValidY =false;
        if(y >= 0 && y < mapSize){
            isValidY=true;
        }
        return isValidX && isValidY;
    }

    public Position getPxANDPy(){ return PxANDPy; }

    public int getSize(){
        return mapSize;
    }

    public Obstacle getValueAt(int x, int y){
        return map[y][x];
    }
}

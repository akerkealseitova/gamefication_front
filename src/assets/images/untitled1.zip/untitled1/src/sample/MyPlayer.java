package sample;

public class MyPlayer implements Player{
    private Position position;
    private Map map;
    char tankDirection = 'r';
    int cSize;
    boolean isHidden;

    public MyPlayer(Position position, int cellSize){
        this.position = position;
        this.cSize = cellSize;
    }

    private boolean MoveChecker(int x, int y) {
        if(!map.CheckerMap(x, y)){
            return false;
        }
        if(map.getValueAt(x, y).CheckerSkipT()){
            isHidden = map.getValueAt(x, y).CheckerHide();
            return true;
        }
        return false;
    }
    @Override
    public void moveUp() {
        tankDirection = 'u';
        if(MoveChecker(position.getX(), position.getY()-1)){
            position.setY(position.getY()-1);
        }
    }

    @Override
    public void moveDown() {
        tankDirection = 'd';
        if(MoveChecker(position.getX(), position.getY()+1)){
            position.setY(position.getY()+1);
        }
    }

    @Override
    public void moveLeft() {
        tankDirection = 'l';
        if(MoveChecker(position.getX()-1, position.getY())){
            position.setX(position.getX()-1);
        }
    }

    @Override
    public void moveRight() {
        tankDirection = 'r';
        if(MoveChecker(position.getX()+1, position.getY())){
            position.setX(position.getX()+1);
        }
    }

    @Override
    public void setMap(Map map) {
        this.map = map;
    }

    @Override
    public Position getPosition() {
        return position;
    }

    public char getTankDirection(){
        return this.tankDirection;
    }
}


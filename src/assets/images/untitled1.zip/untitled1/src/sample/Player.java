package sample;

public interface Player {
    void moveUp();
    void moveDown();
    void moveLeft();
    void moveRight();
    void setMap(Map map);
    Position getPosition();
}

package sample;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Game extends Application {
    private Map map;
    private Tank myPlayer;
    private List<Bullet> bulletList = new LinkedList<>();
    private int CSize = 32;
    private Scene scene;
    private Stage stage;
    private GraphicsContext gc;


    private void i() throws Exception{
        stage.setTitle( "World of Tanks" );
        Group root = new Group();
        scene = new Scene(root);
        scene.setOnKeyPressed(this::keyEventEventHandler);
        stage.setScene(scene);
        Scanner in = new Scanner(System.in);
        map = new Map(in);
        map.setCellSize(CSize);
        int s = map.getSize();
        Canvas canvas = new Canvas(s* CSize, s* CSize);
        root.getChildren().add( canvas );
        gc = canvas.getGraphicsContext2D();

        myPlayer = new Tank(map.getPxANDPy(), CSize);
        myPlayer.setMap(map);

    }

    public void start(Stage stage) throws Exception {
        this.stage = stage;
        i();
        updateAll();
        new AnimationTimer() {
            private long last = 0;
            public void handle(long n)
            {
                if(n - last >= 40_000_000){
                    updateAll();
                    last = n;
                }
            }
        }.start();
        stage.show();
    }

    public void keyEventEventHandler(KeyEvent keyEvent){
        if(keyEvent.getCode() == KeyCode.W){
            myPlayer.moveUp();
        }else if(keyEvent.getCode() == KeyCode.S){
            myPlayer.moveDown();
        }else if(keyEvent.getCode() == KeyCode.D){
            myPlayer.moveRight();
        }else if(keyEvent.getCode() == KeyCode.A){
            myPlayer.moveLeft();
        }else if(keyEvent.getCode() == KeyCode.SPACE){
            Bullet bullet = new Bullet(myPlayer.getPosition(), myPlayer.getTankDirection(), CSize,map);
            bulletList.add(bullet);
        }
    }

    public void updateBullets(GraphicsContext gc){
        Iterator<Bullet> iterator = bulletList.iterator();
        String out="";
        while(iterator.hasNext()){
            Bullet bullet = iterator.next();
            bullet.update(gc);

            if(!bullet.isAlive()){
                bulletList.remove(bullet);
            }
        }
    }
    private void updateAll(){
        map.drawMap(gc);
        myPlayer.drawTank(gc);
        updateBullets(gc);
    }
    public static void main(String[] args) {
        launch(args);
    }
}

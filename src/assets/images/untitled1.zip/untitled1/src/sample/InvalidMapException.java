package sample;

public class InvalidMapException extends Exception {
    public InvalidMapException(String message){
        super(message);
    }
}

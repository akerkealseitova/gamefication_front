package sample;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

public class Tank extends MyPlayer {
    private int CSize;
    private Position position;

    public Tank(Position position, int cellSize) {
        super(position, cellSize);
        this.position = position;
        this.CSize = cellSize;
    }


    public void drawTank(GraphicsContext gc){
        if(super.isHidden){
            return;
        }
        int x = position.getX() * CSize, y = position.getY() * CSize;
        Image image=new Image("img/Up.png");
        switch (super.tankDirection) {
            case 'l':
                image=new Image("img/Left.png");
                break;
            case 'r':
                image=new Image("img/Right.png");
                break;
            case 'u':
                image=new Image("img/Up.png");
                break;
            case 'd':
                image=new Image("img/Down.png");
                break;
        }
        gc.drawImage(image, x, y);
    }



}
